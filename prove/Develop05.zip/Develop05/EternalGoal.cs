
class EternalGoal : Goal
{
    public EternalGoal(string title, string description) : base(title,description){}
    override public void Display()
    {
        
    }
    override public string GetSaveString()
    {
        return $"EternalGoal:{_title},{_description},{_points}";
    }
    public override void Complete()
    {
        Console.WriteLine("Eternal Goal Complete function should not be called.");
    }
}