class GoalList
{
    protected int _pointTotal;
    protected List<Goal>_goal=new();

    public void AddGoal()
    {
        
    }
    public void Save()
    {
        
    }
    public void Load()
    {
        
    }
}