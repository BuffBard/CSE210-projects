abstract class Goal
{
    protected string _title;
    protected string _description;
    protected int _points;
    protected bool _completed;

    public Goal(string title, string description)
    {
        _title=title;
        _description=description;
    }
    abstract public void Display();
    abstract public string GetSaveString();
    abstract public void Complete();
}