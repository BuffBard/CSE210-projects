
class SimpleGoal : Goal
{
    public SimpleGoal(string title, string description) : base(title,description)
    {
        
    }
    override public void Display()
    {
        
    }
    override public string GetSaveString()
    {
        return $"SimpleGoal:{_title},{_description},{_points},{_completed}";
    }
    public override void Complete()
    {
        _completed=true;
    }
}