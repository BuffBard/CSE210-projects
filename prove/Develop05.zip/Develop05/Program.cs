using System;

class Program
{
    static void Main(string[] args)
    {
        List<string> _menu=new(){"Create New Goal", "List Goals","Save Goals","Load Goals","Record Event","Quit"};
        Console.WriteLine("Menu Options:");
        foreach(string option in _menu){
            Console.WriteLine($"    {option}");
        }
    }
}