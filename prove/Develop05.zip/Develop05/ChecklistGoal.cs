
class ChecklistGoal : Goal
{
    protected int _iterations;
    protected int _bonusPoints;
    protected int _threshold;
    public ChecklistGoal(string title, string description,int iterations,int bonusPoints,int threshhold) : base(title,description)
    {
        _iterations=iterations;
        _bonusPoints=bonusPoints;
        _threshold=threshhold;
    }
    override public void Display()
    {
        
    }
    override public string GetSaveString()
    {
        return $"SimpleGoal:{_title},{_description},{_points},{_completed},{_bonusPoints},{_threshold},{_iterations}";
    }
    public override void Complete()
    {
        _completed=true;
    }
}